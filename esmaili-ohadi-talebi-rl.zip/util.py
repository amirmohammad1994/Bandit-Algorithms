def incrementalAvg(n,avg,element):
    return ((n-1)*avg + element)/n 

