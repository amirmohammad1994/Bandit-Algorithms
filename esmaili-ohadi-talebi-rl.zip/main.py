from experiment import *

n_sim = 40
params = [{
"time_horizon" :  1000,
"number_of_arms" : 10,
}]




#createBanditInstancesAndSimulate(params,n_sim)
# experiment1()
experiment2()