##bandit algorithms

//python3 numpy matplotlib 
```$ python main.py
```

##amir-esi-rad implementation
graph.ipynb


##report
rl-practical.pdf